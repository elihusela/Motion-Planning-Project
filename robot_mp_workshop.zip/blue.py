from arr2_epec_cs_ex import *

def initialize(params):
  print(params)

def play_turn(params):
  print(params)
  params[0].append([Point_2(5,5), Point_2(5, 8), Point_2(5, 10)])
  params[0].append([Point_2(5, 10), Point_2(5, 13), Point_2(5, 15)])